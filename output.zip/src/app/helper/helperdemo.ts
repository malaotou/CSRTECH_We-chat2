export class Helperdemo {
}
export function square(x){
    return Math.pow(x,2);
}

export const  PI=Math.PI;