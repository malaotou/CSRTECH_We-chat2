export class Register {
    username:string;
    password:string;
    firstname:string;
    lastname:string;
    phoneNum:string;

}
