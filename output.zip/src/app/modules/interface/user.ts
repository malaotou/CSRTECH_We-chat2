export interface User {
    id:number,
    name:string,
    //isStaff(id:number):boolean
}
