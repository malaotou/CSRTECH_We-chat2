import { Message} from './message'
export class Chatmessages {
    chatGroupId:number;
    messages:Array<Message>
    constructor(id:number,messsages:Array<Message>){
        this.chatGroupId=id;
        this.messages=messsages;
    }
    
}
