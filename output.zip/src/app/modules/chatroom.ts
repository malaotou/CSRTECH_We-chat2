export class Chatroom {
}
