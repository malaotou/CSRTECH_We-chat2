import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mychat',
  templateUrl: './mychat.component.html',
  styleUrls: ['./mychat.component.css']
})
export class MychatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
