import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myfavorite',
  templateUrl: './myfavorite.component.html',
  styleUrls: ['./myfavorite.component.css']
})
export class MyfavoriteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
