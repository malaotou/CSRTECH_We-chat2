import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactdetail',
  templateUrl: './contactdetail.component.html',
  styleUrls: ['./contactdetail.component.css']
})
export class ContactdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
