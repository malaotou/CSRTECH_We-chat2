
function User(name,password){
    this.name=name;
    this.password=password;
}

module.exports=User;